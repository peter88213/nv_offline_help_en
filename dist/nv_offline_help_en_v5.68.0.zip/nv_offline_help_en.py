"""English offline help pages for novelibre.

Requires Python 3.7+
Copyright (c) 2024-2026 Peter Triesberger
For further information see https://github.com/peter88213/nv_offline_help_en
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def ready_to_close(self):
        return True

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
import webbrowser


class OfflineHelp:

    def __init__(self, helpSite):
        self.helpSite = helpSite

    def open_help_page(self, page, site=None):
        if not site:
            site = self.helpSite
            if '#' in page:
                page = page.split('#')[0]
            elif not page.endswith('.html'):
                if not page.endswith('/'):
                    page = f'{page}/'
                page = f'{page}index.html'
        print(f'{site}/{page}')
        webbrowser.open(f'{site}/{page}')

from pathlib import Path
from shutil import rmtree
import os


class Plugin(PluginBase):
    VERSION = '5.68.0'
    API_VERSION = '5.63'
    DESCRIPTION = 'English offline help pages'
    URL = 'https://github.com/peter88213/nv_offline_help_en'

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        homeDir = str(Path.home()).replace('\\', '/')
        self.helpSite = f'{homeDir}/.novx/help'
        if not os.path.isdir(self.helpSite):
            raise FileNotFoundError('Offline help pages not installed')

        super().install(model, view, controller)
        self.originalHelpService = self._ctrl.helpService
        self._ctrl.helpService = OfflineHelp(self.helpSite)

    def uninstall(self):
        rmtree(self.helpSite, ignore_errors=True)
        self._ctrl.helpService = self.originalHelpService
        self.isActive = False

